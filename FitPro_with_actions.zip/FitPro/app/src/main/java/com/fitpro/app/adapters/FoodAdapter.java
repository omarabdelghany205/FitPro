package com.fitpro.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fitpro.app.R;
import com.fitpro.app.models.FoodEntry;

import java.util.ArrayList;
import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {

    private List<FoodEntry> entries = new ArrayList<>();
    private boolean isArabic;

    public FoodAdapter(boolean isArabic) {
        this.isArabic = isArabic;
    }

    public void setEntries(List<FoodEntry> entries) {
        this.entries = entries;
        notifyDataSetChanged();
    }

    public void addEntry(FoodEntry entry) {
        entries.add(0, entry);
        notifyItemInserted(0);
    }

    public void setArabic(boolean arabic) {
        this.isArabic = arabic;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_food, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodEntry entry = entries.get(position);
        holder.tvEmoji.setText(entry.getEmoji() != null ? entry.getEmoji() : "🍽");
        holder.tvName.setText(entry.getDisplayName(isArabic));
        holder.tvMacros.setText(entry.getMacrosSummary());
        holder.tvCalories.setText(String.valueOf(entry.getCalories()));
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class FoodViewHolder extends RecyclerView.ViewHolder {
        TextView tvEmoji, tvName, tvMacros, tvCalories;

        FoodViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmoji = itemView.findViewById(R.id.tv_food_emoji);
            tvName = itemView.findViewById(R.id.tv_item_name);
            tvMacros = itemView.findViewById(R.id.tv_item_macros);
            tvCalories = itemView.findViewById(R.id.tv_item_calories);
        }
    }
}
