package com.fitpro.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fitpro.app.R;
import com.fitpro.app.models.BodyPredictionRequest;
import com.fitpro.app.models.BodyPredictionResult;
import com.fitpro.app.network.RetrofitClient;
import com.fitpro.app.views.BodyShapeView;

import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BodyPredictionFragment extends Fragment {

    private EditText etWeight, etHeight, etAge, etBodyFat;
    private Spinner spinnerGender, spinnerActivity, spinnerGoal, spinnerWeeks;
    private LinearLayout resultsContainer, loadingContainer;
    private BodyShapeView bodyShapeBefore, bodyShapeAfter;

    private TextView tvCurrentWeight, tvPredictedWeight, tvWeightChange;
    private TextView tvCurrentFat, tvPredictedFat, tvFatChange;
    private TextView tvCurrentMuscle, tvPredictedMuscle, tvMuscleChange;
    private TextView tvBmiCurrent, tvBmiPredicted;
    private TextView tvSummary, tvTips;
    private TextView tvBeforeLabel, tvAfterLabel;

    private boolean isArabic;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_body_prediction, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isArabic = Locale.getDefault().getLanguage().equals("ar");
        initViews(view);
        setupSpinners();
        view.findViewById(R.id.btn_predict).setOnClickListener(v -> predict());
    }

    private void initViews(View view) {
        etWeight = view.findViewById(R.id.et_pred_weight);
        etHeight = view.findViewById(R.id.et_pred_height);
        etAge = view.findViewById(R.id.et_pred_age);
        etBodyFat = view.findViewById(R.id.et_pred_body_fat);
        spinnerGender = view.findViewById(R.id.spinner_gender);
        spinnerActivity = view.findViewById(R.id.spinner_pred_activity);
        spinnerGoal = view.findViewById(R.id.spinner_pred_goal);
        spinnerWeeks = view.findViewById(R.id.spinner_weeks);

        resultsContainer = view.findViewById(R.id.prediction_results_container);
        loadingContainer = view.findViewById(R.id.prediction_loading);

        bodyShapeBefore = view.findViewById(R.id.body_shape_before);
        bodyShapeAfter = view.findViewById(R.id.body_shape_after);

        tvCurrentWeight = view.findViewById(R.id.tv_current_weight);
        tvPredictedWeight = view.findViewById(R.id.tv_predicted_weight);
        tvWeightChange = view.findViewById(R.id.tv_weight_change);
        tvCurrentFat = view.findViewById(R.id.tv_current_fat);
        tvPredictedFat = view.findViewById(R.id.tv_predicted_fat);
        tvFatChange = view.findViewById(R.id.tv_fat_change);
        tvCurrentMuscle = view.findViewById(R.id.tv_current_muscle);
        tvPredictedMuscle = view.findViewById(R.id.tv_predicted_muscle);
        tvMuscleChange = view.findViewById(R.id.tv_muscle_change);
        tvBmiCurrent = view.findViewById(R.id.tv_bmi_current);
        tvBmiPredicted = view.findViewById(R.id.tv_bmi_predicted);
        tvSummary = view.findViewById(R.id.tv_prediction_summary);
        tvTips = view.findViewById(R.id.tv_prediction_tips);
        tvBeforeLabel = view.findViewById(R.id.tv_before_label);
        tvAfterLabel = view.findViewById(R.id.tv_after_label);
    }

    private void setupSpinners() {
        
        String[] genders = {
            getString(R.string.gender_male),
            getString(R.string.gender_female)
        };
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, genders
        );
        genderAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerGender.setAdapter(genderAdapter);

        
        String[] activities = {
            getString(R.string.sedentary),
            getString(R.string.light_active),
            getString(R.string.moderate),
            getString(R.string.very_active)
        };
        ArrayAdapter<String> activityAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, activities
        );
        activityAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerActivity.setAdapter(activityAdapter);
        spinnerActivity.setSelection(2);

        
        String[] goals = {
            getString(R.string.goal_lose_weight),
            getString(R.string.goal_gain_muscle),
            getString(R.string.goal_maintain)
        };
        ArrayAdapter<String> goalAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, goals
        );
        goalAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerGoal.setAdapter(goalAdapter);

        
        String[] weeks = {
            "4 " + getString(R.string.weeks_label),
            "8 " + getString(R.string.weeks_label),
            "12 " + getString(R.string.weeks_label),
            "16 " + getString(R.string.weeks_label),
            "24 " + getString(R.string.weeks_label)
        };
        ArrayAdapter<String> weeksAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, weeks
        );
        weeksAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerWeeks.setAdapter(weeksAdapter);
        spinnerWeeks.setSelection(2);
    }

    private void predict() {
        float weight = parseFloat(etWeight, 75f);
        float height = parseFloat(etHeight, 170f);
        int age = (int) parseFloat(etAge, 25f);
        float bodyFat = parseFloat(etBodyFat, 20f);
        String gender = spinnerGender.getSelectedItemPosition() == 0 ? "male" : "female";
        int activityLevel = spinnerActivity.getSelectedItemPosition();
        String goal;
        switch (spinnerGoal.getSelectedItemPosition()) {
            case 0: goal = "lose"; break;
            case 1: goal = "gain"; break;
            default: goal = "maintain"; break;
        }
        int[] weekOptions = {4, 8, 12, 16, 24};
        int weeks = weekOptions[spinnerWeeks.getSelectedItemPosition()];

        
        loadingContainer.setVisibility(View.VISIBLE);
        resultsContainer.setVisibility(View.GONE);

        BodyPredictionRequest request = new BodyPredictionRequest(
            weight, height, age, gender, bodyFat, activityLevel, goal, weeks
        );

        RetrofitClient.getInstance().getApiService()
            .predictBody(request)
            .enqueue(new Callback<BodyPredictionResult>() {
                @Override
                public void onResponse(@NonNull Call<BodyPredictionResult> call,
                                       @NonNull Response<BodyPredictionResult> response) {
                    loadingContainer.setVisibility(View.GONE);
                    if (response.isSuccessful() && response.body() != null) {
                        showResults(response.body());
                    } else {
                        
                        showResults(calculateLocally(weight, height, age, gender,
                            bodyFat, activityLevel, goal, weeks));
                    }
                }

                @Override
                public void onFailure(@NonNull Call<BodyPredictionResult> call,
                                      @NonNull Throwable t) {
                    loadingContainer.setVisibility(View.GONE);
                    
                    showResults(calculateLocally(weight, height, age, gender,
                        bodyFat, activityLevel, goal, weeks));
                }
            });
    }

    
    private BodyPredictionResult calculateLocally(float weight, float height, int age,
                                                   String gender, float bodyFat,
                                                   int activityLevel, String goal, int weeks) {
        float lbm = weight * (1 - bodyFat / 100f);
        float fatMass = weight * (bodyFat / 100f);
        float heightM = height / 100f;
        float bmiCurrent = weight / (heightM * heightM);

        float[] multipliers = {1.2f, 1.375f, 1.55f, 1.725f};
        float actMult = multipliers[Math.min(activityLevel, 3)];
        float bmr = 370 + 21.6f * lbm;
        float tdee = bmr * actMult;

        float weeklyWeightChange;
        float weeklyFatChange;
        float weeklyMuscleChange;

        switch (goal) {
            case "lose":
                weeklyWeightChange = -0.5f; 
                weeklyFatChange = -0.45f;
                weeklyMuscleChange = -0.05f;
                if (activityLevel >= 2) weeklyMuscleChange = 0.05f; 
                break;
            case "gain":
                weeklyWeightChange = 0.3f;
                weeklyFatChange = 0.05f;
                weeklyMuscleChange = 0.25f;
                if (activityLevel < 2) weeklyMuscleChange = 0.1f;
                break;
            default: 
                weeklyWeightChange = 0f;
                weeklyFatChange = -0.05f;
                weeklyMuscleChange = 0.05f;
                break;
        }

        float totalWeightChange = weeklyWeightChange * weeks;
        float totalFatChange = weeklyFatChange * weeks;
        float totalMuscleChange = weeklyMuscleChange * weeks;

        float predictedWeight = weight + totalWeightChange;
        float predictedFatMass = Math.max(fatMass + totalFatChange, weight * 0.05f);
        float predictedMuscleMass = lbm + totalMuscleChange;
        float predictedBodyFat = (predictedFatMass / predictedWeight) * 100f;
        predictedBodyFat = Math.max(5f, Math.min(50f, predictedBodyFat));
        float bmiPredicted = predictedWeight / (heightM * heightM);

        
        String shapeCurrent = getBodyShape(bodyFat, gender);
        String shapePredicted = getBodyShape(predictedBodyFat, gender);

        
        return buildResult(
            weight, predictedWeight, bodyFat, predictedBodyFat,
            lbm, predictedMuscleMass, totalWeightChange, totalFatChange,
            totalMuscleChange, bmiCurrent, bmiPredicted,
            shapeCurrent, shapePredicted, weeks, goal
        );
    }

    private String getBodyShape(float bodyFat, String gender) {
        if ("male".equals(gender)) {
            if (bodyFat < 10) return "athletic";
            if (bodyFat < 18) return "fit";
            if (bodyFat < 25) return "average";
            return "overweight";
        } else {
            if (bodyFat < 18) return "athletic";
            if (bodyFat < 25) return "fit";
            if (bodyFat < 32) return "average";
            return "overweight";
        }
    }

    private BodyPredictionResult buildResult(float cw, float pw, float cf, float pf,
                                              float cm, float pm, float wc, float fc,
                                              float mc, float bc, float bp,
                                              String sc, String sp, int weeks, String goal) {
        
        String json = String.format(Locale.US,
            "{\"current_weight\":%.1f,\"predicted_weight\":%.1f," +
            "\"current_body_fat\":%.1f,\"predicted_body_fat\":%.1f," +
            "\"current_muscle_mass\":%.1f,\"predicted_muscle_mass\":%.1f," +
            "\"weight_change\":%.1f,\"fat_change\":%.1f,\"muscle_change\":%.1f," +
            "\"bmi_current\":%.1f,\"bmi_predicted\":%.1f," +
            "\"body_shape_current\":\"%s\",\"body_shape_predicted\":\"%s\"," +
            "\"weeks\":%d,\"goal\":\"%s\"," +
            "\"summary_en\":\"Based on your profile, with %d weeks of commitment you can expect to %s %.1f kg. Your body fat is projected to go from %.1f%% to %.1f%%." +
            "\",\"summary_ar\":\"بناءً على بياناتك، مع %d أسبوع من الالتزام، من المتوقع أنك هت%s %.1f كجم. نسبة الدهون هتتغير من %.1f%% لـ %.1f%%." +
            "\",\"tips_en\":\"Stay consistent with your workouts and nutrition plan. Track your progress weekly for best results." +
            "\",\"tips_ar\":\"حافظ على الاستمرارية في التمارين والنظام الغذائي. تابع تقدمك أسبوعياً لأفضل النتائج.\"}",
            cw, pw, cf, pf, cm, pm, wc, fc, mc, bc, bp, sc, sp, weeks, goal,
            weeks, (wc < 0 ? "lose" : "gain"), Math.abs(wc), cf, pf,
            weeks, (wc < 0 ? "خسر" : "كسب"), Math.abs(wc), cf, pf
        );
        return new com.google.gson.Gson().fromJson(json, BodyPredictionResult.class);
    }

    private void showResults(BodyPredictionResult result) {
        resultsContainer.setVisibility(View.VISIBLE);

        
        String gender = spinnerGender.getSelectedItemPosition() == 0 ? "male" : "female";
        bodyShapeBefore.setBodyMetrics(result.getCurrentBodyFat(), result.getCurrentMuscleMass(), gender);
        bodyShapeBefore.setColors(0xFF6B6B6B, 0xFF8B8B8B);

        bodyShapeAfter.setBodyMetrics(result.getPredictedBodyFat(), result.getPredictedMuscleMass(), gender);
        bodyShapeAfter.setColors(0xFFC8A960, 0xFFE8D5A0);

        
        tvBeforeLabel.setText(isArabic ? "الآن" : "Now");
        tvAfterLabel.setText(isArabic
            ? "بعد " + result.getWeeks() + " أسبوع"
            : "After " + result.getWeeks() + " weeks");

        
        tvCurrentWeight.setText(String.format(Locale.US, "%.1f kg", result.getCurrentWeight()));
        tvPredictedWeight.setText(String.format(Locale.US, "%.1f kg", result.getPredictedWeight()));
        float wc = result.getWeightChange();
        tvWeightChange.setText(String.format(Locale.US, "%s%.1f kg",
            wc >= 0 ? "+" : "", wc));
        tvWeightChange.setTextColor(getChangeColor(wc, result.getGoal()));

        
        tvCurrentFat.setText(String.format(Locale.US, "%.1f%%", result.getCurrentBodyFat()));
        tvPredictedFat.setText(String.format(Locale.US, "%.1f%%", result.getPredictedBodyFat()));
        float fc = result.getFatChange();
        tvFatChange.setText(String.format(Locale.US, "%s%.1f%%",
            fc >= 0 ? "+" : "", fc));
        tvFatChange.setTextColor(fc <= 0 ? 0xFF4CAF50 : 0xFFD85A30);

        
        tvCurrentMuscle.setText(String.format(Locale.US, "%.1f kg", result.getCurrentMuscleMass()));
        tvPredictedMuscle.setText(String.format(Locale.US, "%.1f kg", result.getPredictedMuscleMass()));
        float mc = result.getMuscleChange();
        tvMuscleChange.setText(String.format(Locale.US, "%s%.1f kg",
            mc >= 0 ? "+" : "", mc));
        tvMuscleChange.setTextColor(mc >= 0 ? 0xFF4CAF50 : 0xFFD85A30);

        
        tvBmiCurrent.setText(String.format(Locale.US, "%.1f", result.getBmiCurrent()));
        tvBmiPredicted.setText(String.format(Locale.US, "%.1f", result.getBmiPredicted()));

        
        tvSummary.setText(isArabic ? result.getSummaryAr() : result.getSummaryEn());
        tvTips.setText(isArabic ? result.getTipsAr() : result.getTipsEn());

        
        resultsContainer.post(() ->
            resultsContainer.getParent().requestChildFocus(resultsContainer, resultsContainer)
        );
    }

    private int getChangeColor(float change, String goal) {
        if ("lose".equals(goal)) {
            return change <= 0 ? 0xFF4CAF50 : 0xFFD85A30;
        } else {
            return change >= 0 ? 0xFF4CAF50 : 0xFFD85A30;
        }
    }

    private float parseFloat(EditText et, float defaultVal) {
        try {
            String text = et.getText().toString().trim();
            return text.isEmpty() ? defaultVal : Float.parseFloat(text);
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }
}
