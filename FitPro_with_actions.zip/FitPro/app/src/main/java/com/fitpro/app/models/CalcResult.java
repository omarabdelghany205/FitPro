package com.fitpro.app.models;

public class CalcResult {

    private int bmr;
    private int tdee;
    private int targetCalories;
    private int proteinGrams;
    private int carbsGrams;
    private int fatsGrams;
    private int proteinPercent;
    private int carbsPercent;
    private int fatsPercent;
    private String goal;

    public CalcResult(int bmr, int tdee, int targetCalories,
                      int proteinGrams, int carbsGrams, int fatsGrams,
                      int proteinPercent, int carbsPercent, int fatsPercent,
                      String goal) {
        this.bmr = bmr;
        this.tdee = tdee;
        this.targetCalories = targetCalories;
        this.proteinGrams = proteinGrams;
        this.carbsGrams = carbsGrams;
        this.fatsGrams = fatsGrams;
        this.proteinPercent = proteinPercent;
        this.carbsPercent = carbsPercent;
        this.fatsPercent = fatsPercent;
        this.goal = goal;
    }

    public int getBmr() { return bmr; }
    public int getTdee() { return tdee; }
    public int getTargetCalories() { return targetCalories; }
    public int getProteinGrams() { return proteinGrams; }
    public int getCarbsGrams() { return carbsGrams; }
    public int getFatsGrams() { return fatsGrams; }
    public int getProteinPercent() { return proteinPercent; }
    public int getCarbsPercent() { return carbsPercent; }
    public int getFatsPercent() { return fatsPercent; }
    public String getGoal() { return goal; }
}
