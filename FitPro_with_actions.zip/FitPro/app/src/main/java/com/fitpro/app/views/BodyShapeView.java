package com.fitpro.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class BodyShapeView extends View {

    private Paint bodyPaint;
    private Paint outlinePaint;
    private Paint glowPaint;
    private Path bodyPath;

    private float bodyFatPercent = 20f;
    private float muscleMass = 55f;
    private String gender = "male";

    private int primaryColor = 0xFFC8A960;
    private int secondaryColor = 0xFFE8D5A0;

    public BodyShapeView(Context context) {
        super(context);
        init();
    }

    public BodyShapeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BodyShapeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bodyPaint.setStyle(Paint.Style.FILL);

        outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        outlinePaint.setStyle(Paint.Style.STROKE);
        outlinePaint.setStrokeWidth(2f);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(6f);
        glowPaint.setAlpha(60);

        bodyPath = new Path();
    }

    public void setBodyMetrics(float bodyFat, float muscle, String gender) {
        this.bodyFatPercent = bodyFat;
        this.muscleMass = muscle;
        this.gender = gender;
        invalidate();
    }

    public void setColors(int primary, int secondary) {
        this.primaryColor = primary;
        this.secondaryColor = secondary;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        float cx = w / 2f;
        float scale = Math.min(w / 200f, h / 400f);

        
        float fatFactor = 1f + (bodyFatPercent - 15f) / 100f;
        float muscleFactor = 1f + (muscleMass - 50f) / 200f;
        fatFactor = Math.max(0.85f, Math.min(1.3f, fatFactor));
        muscleFactor = Math.max(0.9f, Math.min(1.2f, muscleFactor));

        boolean isMale = "male".equalsIgnoreCase(gender);

        
        float shoulderW = (isMale ? 42f : 36f) * scale * muscleFactor;
        float chestW = (isMale ? 38f : 34f) * scale * fatFactor * muscleFactor;
        float waistW = (isMale ? 30f : 26f) * scale * fatFactor;
        float hipW = (isMale ? 32f : 38f) * scale * fatFactor;
        float thighW = (isMale ? 18f : 20f) * scale * fatFactor * muscleFactor;
        float calfW = (isMale ? 12f : 11f) * scale * muscleFactor;
        float armW = (isMale ? 10f : 8f) * scale * muscleFactor;

        
        float headTop = 20f * scale;
        float headR = 18f * scale;
        float neckY = headTop + headR * 2 + 5 * scale;
        float shoulderY = neckY + 12 * scale;
        float chestY = shoulderY + 30 * scale;
        float waistY = chestY + 35 * scale;
        float hipY = waistY + 25 * scale;
        float thighMidY = hipY + 40 * scale;
        float kneeY = thighMidY + 35 * scale;
        float ankleY = kneeY + 40 * scale;

        
        LinearGradient gradient = new LinearGradient(
            cx, headTop, cx, ankleY,
            primaryColor, secondaryColor,
            Shader.TileMode.CLAMP
        );
        bodyPaint.setShader(gradient);
        bodyPaint.setAlpha(50);

        outlinePaint.setColor(primaryColor);
        outlinePaint.setAlpha(180);

        glowPaint.setColor(primaryColor);
        glowPaint.setAlpha(40);

        
        canvas.drawCircle(cx, headTop + headR, headR, bodyPaint);
        canvas.drawCircle(cx, headTop + headR, headR, outlinePaint);

        
        bodyPath.reset();

        
        bodyPath.moveTo(cx - 8 * scale, neckY - 10 * scale);
        bodyPath.lineTo(cx + 8 * scale, neckY - 10 * scale);

        
        bodyPath.cubicTo(
            cx + 15 * scale, neckY,
            cx + shoulderW - 5, shoulderY - 5 * scale,
            cx + shoulderW, shoulderY
        );

        
        bodyPath.cubicTo(
            cx + chestW + 2, chestY,
            cx + waistW + 3, waistY - 10 * scale,
            cx + waistW, waistY
        );

        
        bodyPath.cubicTo(
            cx + waistW + 2, waistY + 10 * scale,
            cx + hipW, hipY - 10 * scale,
            cx + hipW, hipY
        );

        
        bodyPath.cubicTo(
            cx + hipW - 2, hipY + 15 * scale,
            cx + thighW + 5, thighMidY,
            cx + thighW, thighMidY
        );
        bodyPath.cubicTo(
            cx + thighW - 2, kneeY - 10 * scale,
            cx + calfW + 3, kneeY,
            cx + calfW + 2, kneeY
        );
        bodyPath.lineTo(cx + calfW, ankleY);

        
        bodyPath.lineTo(cx + calfW + 6 * scale, ankleY + 5 * scale);
        bodyPath.lineTo(cx + 2, ankleY + 5 * scale);
        bodyPath.lineTo(cx + 2, ankleY);

        
        bodyPath.lineTo(cx + 4, kneeY);
        bodyPath.cubicTo(cx + 5, thighMidY, cx + 6, hipY + 10 * scale, cx + 5, hipY);

        
        bodyPath.lineTo(cx - 5, hipY);

        
        bodyPath.cubicTo(cx - 6, hipY + 10 * scale, cx - 5, thighMidY, cx - 4, kneeY);
        bodyPath.lineTo(cx - 2, ankleY);

        
        bodyPath.lineTo(cx - 2, ankleY + 5 * scale);
        bodyPath.lineTo(cx - calfW - 6 * scale, ankleY + 5 * scale);
        bodyPath.lineTo(cx - calfW, ankleY);

        
        bodyPath.lineTo(cx - calfW - 2, kneeY);
        bodyPath.cubicTo(
            cx - calfW - 3, kneeY,
            cx - thighW + 2, kneeY - 10 * scale,
            cx - thighW, thighMidY
        );
        bodyPath.cubicTo(
            cx - thighW - 5, thighMidY,
            cx - hipW + 2, hipY + 15 * scale,
            cx - hipW, hipY
        );

        
        bodyPath.cubicTo(
            cx - hipW, hipY - 10 * scale,
            cx - waistW - 2, waistY + 10 * scale,
            cx - waistW, waistY
        );

        
        bodyPath.cubicTo(
            cx - waistW - 3, waistY - 10 * scale,
            cx - chestW - 2, chestY,
            cx - shoulderW, shoulderY
        );

        
        bodyPath.cubicTo(
            cx - shoulderW + 5, shoulderY - 5 * scale,
            cx - 15 * scale, neckY,
            cx - 8 * scale, neckY - 10 * scale
        );

        bodyPath.close();

        canvas.drawPath(bodyPath, bodyPaint);
        canvas.drawPath(bodyPath, outlinePaint);
        canvas.drawPath(bodyPath, glowPaint);

        
        drawArm(canvas, cx, shoulderY, shoulderW, armW, scale, true);
        drawArm(canvas, cx, shoulderY, shoulderW, armW, scale, false);
    }

    private void drawArm(Canvas canvas, float cx, float shoulderY,
                          float shoulderW, float armW, float scale, boolean right) {
        float sign = right ? 1 : -1;
        Path armPath = new Path();

        float startX = cx + sign * shoulderW;
        float startY = shoulderY;
        float elbowX = cx + sign * (shoulderW + 12 * scale);
        float elbowY = shoulderY + 55 * scale;
        float handX = cx + sign * (shoulderW + 8 * scale);
        float handY = shoulderY + 100 * scale;

        
        armPath.moveTo(startX, startY);
        armPath.cubicTo(
            startX + sign * 5 * scale, startY + 20 * scale,
            elbowX + sign * armW / 2, elbowY - 10 * scale,
            elbowX + sign * armW / 2, elbowY
        );
        armPath.cubicTo(
            elbowX + sign * armW / 2, elbowY + 10 * scale,
            handX + sign * armW / 2, handY - 15 * scale,
            handX + sign * armW / 2, handY
        );

        
        armPath.cubicTo(
            handX + sign * armW / 2, handY + 8 * scale,
            handX - sign * armW / 2, handY + 8 * scale,
            handX - sign * armW / 2, handY
        );

        
        armPath.cubicTo(
            handX - sign * armW / 2, handY - 15 * scale,
            elbowX - sign * armW / 2, elbowY + 10 * scale,
            elbowX - sign * armW / 2, elbowY
        );
        armPath.cubicTo(
            elbowX - sign * armW / 2, elbowY - 10 * scale,
            startX - sign * 2 * scale, startY + 20 * scale,
            startX - sign * 3 * scale, startY + 5 * scale
        );

        armPath.close();

        canvas.drawPath(armPath, bodyPaint);
        canvas.drawPath(armPath, outlinePaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int defaultW = 250;
        int defaultH = 420;

        int w = resolveSize(defaultW, widthMeasureSpec);
        int h = resolveSize(defaultH, heightMeasureSpec);

        setMeasuredDimension(w, h);
    }
}
