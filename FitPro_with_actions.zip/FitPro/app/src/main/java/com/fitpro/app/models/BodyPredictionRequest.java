package com.fitpro.app.models;

import com.google.gson.annotations.SerializedName;

public class BodyPredictionRequest {

    @SerializedName("weight")
    private float weight;

    @SerializedName("height")
    private float height;

    @SerializedName("age")
    private int age;

    @SerializedName("gender")
    private String gender;

    @SerializedName("body_fat")
    private float bodyFat;

    @SerializedName("activity_level")
    private int activityLevel;

    @SerializedName("goal")
    private String goal;

    @SerializedName("weeks")
    private int weeks;

    public BodyPredictionRequest(float weight, float height, int age, String gender,
                                  float bodyFat, int activityLevel, String goal, int weeks) {
        this.weight = weight;
        this.height = height;
        this.age = age;
        this.gender = gender;
        this.bodyFat = bodyFat;
        this.activityLevel = activityLevel;
        this.goal = goal;
        this.weeks = weeks;
    }

    
    public float getWeight() { return weight; }
    public float getHeight() { return height; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public float getBodyFat() { return bodyFat; }
    public int getActivityLevel() { return activityLevel; }
    public String getGoal() { return goal; }
    public int getWeeks() { return weeks; }
}
