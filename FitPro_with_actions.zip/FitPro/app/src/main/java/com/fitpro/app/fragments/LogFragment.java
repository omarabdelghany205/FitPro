package com.fitpro.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fitpro.app.R;
import com.fitpro.app.adapters.FoodAdapter;
import com.fitpro.app.database.AppDatabase;
import com.fitpro.app.database.FoodEntryDao;
import com.fitpro.app.models.FoodEntry;
import com.fitpro.app.utils.DateUtils;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class LogFragment extends Fragment {

    private TextView tvLogDate, tvTotalCal, tvTotalP, tvTotalC, tvTotalF, tvNoMeals;
    private RecyclerView rvLogMeals;
    private FoodAdapter adapter;
    private FoodEntryDao dao;
    private boolean isArabic;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_log, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isArabic = Locale.getDefault().getLanguage().equals("ar");
        dao = AppDatabase.getInstance(requireContext()).foodEntryDao();
        initViews(view);
        setupRecyclerView();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void initViews(View view) {
        tvLogDate = view.findViewById(R.id.tv_log_date);
        tvTotalCal = view.findViewById(R.id.tv_total_cal);
        tvTotalP = view.findViewById(R.id.tv_total_p);
        tvTotalC = view.findViewById(R.id.tv_total_c);
        tvTotalF = view.findViewById(R.id.tv_total_f);
        tvNoMeals = view.findViewById(R.id.tv_no_meals);
        rvLogMeals = view.findViewById(R.id.rv_log_meals);
        tvLogDate.setText(DateUtils.getDisplayDate(isArabic));
    }

    private void setupRecyclerView() {
        adapter = new FoodAdapter(isArabic);
        rvLogMeals.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvLogMeals.setAdapter(adapter);
    }

    private void loadData() {
        Executors.newSingleThreadExecutor().execute(() -> {
            String today = DateUtils.getTodayDbFormat();
            List<FoodEntry> entries = dao.getEntriesByDate(today);
            int totalCal = dao.getTotalCaloriesByDate(today);
            int totalP = dao.getTotalProteinByDate(today);
            int totalC = dao.getTotalCarbsByDate(today);
            int totalF = dao.getTotalFatsByDate(today);

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    tvTotalCal.setText(String.valueOf(totalCal));
                    tvTotalP.setText(totalP + "g");
                    tvTotalC.setText(totalC + "g");
                    tvTotalF.setText(totalF + "g");
                    adapter.setEntries(entries);

                    if (entries.isEmpty()) {
                        tvNoMeals.setVisibility(View.VISIBLE);
                        rvLogMeals.setVisibility(View.GONE);
                    } else {
                        tvNoMeals.setVisibility(View.GONE);
                        rvLogMeals.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }
}
