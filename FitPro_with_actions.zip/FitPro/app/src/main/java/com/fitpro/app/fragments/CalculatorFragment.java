package com.fitpro.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fitpro.app.R;
import com.fitpro.app.models.CalcResult;
import com.fitpro.app.utils.KatchMcArdleCalculator;

public class CalculatorFragment extends Fragment {

    private EditText etWeight, etHeight, etAge, etBodyFat;
    private Spinner spinnerActivity, spinnerGoal;
    private LinearLayout resultsContainer;
    private TextView tvBmr, tvTdee, tvTarget, tvTargetLabel;
    private TextView tvProteinG, tvCarbsG, tvFatsG;
    private TextView tvProteinPct, tvCarbsPct, tvFatsPct;
    private View macroBarProtein, macroBarCarbs, macroBarFats;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_calculator, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        setupSpinners();
        view.findViewById(R.id.btn_calculate).setOnClickListener(v -> calculate());
    }

    private void initViews(View view) {
        etWeight = view.findViewById(R.id.et_weight);
        etHeight = view.findViewById(R.id.et_height);
        etAge = view.findViewById(R.id.et_age);
        etBodyFat = view.findViewById(R.id.et_body_fat);
        spinnerActivity = view.findViewById(R.id.spinner_activity);
        spinnerGoal = view.findViewById(R.id.spinner_goal);
        resultsContainer = view.findViewById(R.id.results_container);
        tvBmr = view.findViewById(R.id.tv_bmr);
        tvTdee = view.findViewById(R.id.tv_tdee);
        tvTarget = view.findViewById(R.id.tv_target);
        tvTargetLabel = view.findViewById(R.id.tv_target_label);
        tvProteinG = view.findViewById(R.id.tv_protein_g);
        tvCarbsG = view.findViewById(R.id.tv_carbs_g);
        tvFatsG = view.findViewById(R.id.tv_fats_g);
        tvProteinPct = view.findViewById(R.id.tv_protein_pct);
        tvCarbsPct = view.findViewById(R.id.tv_carbs_pct);
        tvFatsPct = view.findViewById(R.id.tv_fats_pct);
        macroBarProtein = view.findViewById(R.id.macro_bar_protein);
        macroBarCarbs = view.findViewById(R.id.macro_bar_carbs);
        macroBarFats = view.findViewById(R.id.macro_bar_fats);
    }

    private void setupSpinners() {
        String[] activityLevels = {
            getString(R.string.sedentary),
            getString(R.string.light_active),
            getString(R.string.moderate),
            getString(R.string.very_active)
        };
        ArrayAdapter<String> activityAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, activityLevels
        );
        activityAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerActivity.setAdapter(activityAdapter);
        spinnerActivity.setSelection(2);

        String[] goals = {
            getString(R.string.cutting),
            getString(R.string.bulking)
        };
        ArrayAdapter<String> goalAdapter = new ArrayAdapter<>(
            requireContext(), R.layout.spinner_item, goals
        );
        goalAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerGoal.setAdapter(goalAdapter);
    }

    private void calculate() {
        float weight = parseFloat(etWeight, 75f);
        float bodyFat = parseFloat(etBodyFat, 18f);
        float activityMultiplier = KatchMcArdleCalculator.getActivityMultiplier(
            spinnerActivity.getSelectedItemPosition()
        );
        String goal = spinnerGoal.getSelectedItemPosition() == 0
            ? KatchMcArdleCalculator.GOAL_CUT
            : KatchMcArdleCalculator.GOAL_BULK;

        CalcResult result = KatchMcArdleCalculator.calculate(
            weight, bodyFat, activityMultiplier, goal
        );

        showResults(result);
    }

    private void showResults(CalcResult result) {
        resultsContainer.setVisibility(View.VISIBLE);

        tvBmr.setText(String.valueOf(result.getBmr()));
        tvTdee.setText(String.valueOf(result.getTdee()));
        tvTarget.setText(String.valueOf(result.getTargetCalories()));

        String goalLabel = result.getGoal().equals(KatchMcArdleCalculator.GOAL_CUT)
            ? getString(R.string.cutting) : getString(R.string.bulking);
        tvTargetLabel.setText(getString(R.string.target_label) + " — " + goalLabel);

        tvProteinG.setText(result.getProteinGrams() + "g");
        tvCarbsG.setText(result.getCarbsGrams() + "g");
        tvFatsG.setText(result.getFatsGrams() + "g");

        tvProteinPct.setText(getString(R.string.protein) + " · " + result.getProteinPercent() + "%");
        tvCarbsPct.setText(getString(R.string.carbs) + " · " + result.getCarbsPercent() + "%");
        tvFatsPct.setText(getString(R.string.fats) + " · " + result.getFatsPercent() + "%");

        setWeight(macroBarProtein, result.getProteinPercent());
        setWeight(macroBarCarbs, result.getCarbsPercent());
        setWeight(macroBarFats, result.getFatsPercent());

        resultsContainer.post(() ->
            resultsContainer.getParent().requestChildFocus(resultsContainer, resultsContainer)
        );
    }

    private void setWeight(View bar, int percent) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) bar.getLayoutParams();
        params.weight = percent;
        bar.setLayoutParams(params);
    }

    private float parseFloat(EditText et, float defaultVal) {
        try {
            String text = et.getText().toString().trim();
            return text.isEmpty() ? defaultVal : Float.parseFloat(text);
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }
}
