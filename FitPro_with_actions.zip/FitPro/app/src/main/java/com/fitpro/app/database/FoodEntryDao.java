package com.fitpro.app.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.fitpro.app.models.FoodEntry;

import java.util.List;

@Dao
public interface FoodEntryDao {

    @Insert
    long insert(FoodEntry entry);

    @Delete
    void delete(FoodEntry entry);

    @Query("SELECT * FROM food_entries WHERE date = :date ORDER BY timestamp DESC")
    List<FoodEntry> getEntriesByDate(String date);

    @Query("SELECT COALESCE(SUM(calories), 0) FROM food_entries WHERE date = :date")
    int getTotalCaloriesByDate(String date);

    @Query("SELECT COALESCE(SUM(protein), 0) FROM food_entries WHERE date = :date")
    int getTotalProteinByDate(String date);

    @Query("SELECT COALESCE(SUM(carbs), 0) FROM food_entries WHERE date = :date")
    int getTotalCarbsByDate(String date);

    @Query("SELECT COALESCE(SUM(fats), 0) FROM food_entries WHERE date = :date")
    int getTotalFatsByDate(String date);

    @Query("DELETE FROM food_entries WHERE date = :date")
    void deleteAllByDate(String date);

    @Query("SELECT * FROM food_entries ORDER BY timestamp DESC LIMIT :limit")
    List<FoodEntry> getRecentEntries(int limit);

    @Query("SELECT COUNT(*) FROM food_entries WHERE date = :date")
    int getEntryCountByDate(String date);
}
