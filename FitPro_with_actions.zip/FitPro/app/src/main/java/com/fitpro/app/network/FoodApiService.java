package com.fitpro.app.network;

import com.fitpro.app.models.BodyPredictionRequest;
import com.fitpro.app.models.BodyPredictionResult;
import com.fitpro.app.models.ScanResponse;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface FoodApiService {

    @Multipart
    @POST("/api/v1/predict")
    Call<ScanResponse> predictFood(@Part MultipartBody.Part image);

    @POST("/api/v1/body-predict")
    Call<BodyPredictionResult> predictBody(@Body BodyPredictionRequest request);
}
