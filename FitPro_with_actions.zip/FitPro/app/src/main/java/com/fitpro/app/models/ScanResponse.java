package com.fitpro.app.models;

import com.google.gson.annotations.SerializedName;

public class ScanResponse {

    @SerializedName("food_name_ar")
    private String foodNameAr;

    @SerializedName("food_name_en")
    private String foodNameEn;

    @SerializedName("calories")
    private int calories;

    @SerializedName("protein")
    private int protein;

    @SerializedName("carbs")
    private int carbs;

    @SerializedName("fats")
    private int fats;

    @SerializedName("confidence")
    private float confidence;

    @SerializedName("food_class")
    private String foodClass;

    public String getFoodNameAr() { return foodNameAr; }
    public String getFoodNameEn() { return foodNameEn; }
    public int getCalories() { return calories; }
    public int getProtein() { return protein; }
    public int getCarbs() { return carbs; }
    public int getFats() { return fats; }
    public float getConfidence() { return confidence; }
    public String getFoodClass() { return foodClass; }

    public FoodEntry toFoodEntry() {
        FoodEntry entry = new FoodEntry(
            foodNameAr, foodNameEn, calories,
            protein, carbs, fats, "🍽"
        );
        entry.setConfidence(confidence);
        return entry;
    }
}
