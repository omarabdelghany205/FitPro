package com.fitpro.app.models;

import com.google.gson.annotations.SerializedName;

public class BodyPredictionResult {

    @SerializedName("current_weight")
    private float currentWeight;

    @SerializedName("predicted_weight")
    private float predictedWeight;

    @SerializedName("current_body_fat")
    private float currentBodyFat;

    @SerializedName("predicted_body_fat")
    private float predictedBodyFat;

    @SerializedName("current_muscle_mass")
    private float currentMuscleMass;

    @SerializedName("predicted_muscle_mass")
    private float predictedMuscleMass;

    @SerializedName("weight_change")
    private float weightChange;

    @SerializedName("fat_change")
    private float fatChange;

    @SerializedName("muscle_change")
    private float muscleChange;

    @SerializedName("bmi_current")
    private float bmiCurrent;

    @SerializedName("bmi_predicted")
    private float bmiPredicted;

    @SerializedName("body_shape_current")
    private String bodyShapeCurrent;

    @SerializedName("body_shape_predicted")
    private String bodyShapePredicted;

    @SerializedName("weeks")
    private int weeks;

    @SerializedName("goal")
    private String goal;

    @SerializedName("summary_en")
    private String summaryEn;

    @SerializedName("summary_ar")
    private String summaryAr;

    @SerializedName("tips_en")
    private String tipsEn;

    @SerializedName("tips_ar")
    private String tipsAr;

    
    public float getCurrentWeight() { return currentWeight; }
    public float getPredictedWeight() { return predictedWeight; }
    public float getCurrentBodyFat() { return currentBodyFat; }
    public float getPredictedBodyFat() { return predictedBodyFat; }
    public float getCurrentMuscleMass() { return currentMuscleMass; }
    public float getPredictedMuscleMass() { return predictedMuscleMass; }
    public float getWeightChange() { return weightChange; }
    public float getFatChange() { return fatChange; }
    public float getMuscleChange() { return muscleChange; }
    public float getBmiCurrent() { return bmiCurrent; }
    public float getBmiPredicted() { return bmiPredicted; }
    public String getBodyShapeCurrent() { return bodyShapeCurrent; }
    public String getBodyShapePredicted() { return bodyShapePredicted; }
    public int getWeeks() { return weeks; }
    public String getGoal() { return goal; }
    public String getSummaryEn() { return summaryEn; }
    public String getSummaryAr() { return summaryAr; }
    public String getTipsEn() { return tipsEn; }
    public String getTipsAr() { return tipsAr; }
}
