package com.fitpro.app.fragments;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.fitpro.app.R;
import com.fitpro.app.database.AppDatabase;
import com.fitpro.app.database.FoodEntryDao;
import com.fitpro.app.models.FoodEntry;
import com.fitpro.app.models.ScanResponse;
import com.fitpro.app.network.RetrofitClient;
import com.fitpro.app.utils.DateUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanFragment extends Fragment {

    private LinearLayout scanResultContainer, scanLoading, scanResultCard;
    private TextView tvFoodName, tvConfidence;
    private TextView tvResultCal, tvResultProtein, tvResultCarbs, tvResultFats;
    private FoodEntryDao dao;
    private ScanResponse lastScanResult;
    private Uri currentPhotoUri;

    private final ActivityResultLauncher<Intent> cameraLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && currentPhotoUri != null) {
                processImage(currentPhotoUri);
            }
        });

    private final ActivityResultLauncher<Intent> galleryLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                Uri imageUri = result.getData().getData();
                if (imageUri != null) processImage(imageUri);
            }
        });

    private final ActivityResultLauncher<String> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) openCamera();
        });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_scan, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dao = AppDatabase.getInstance(requireContext()).foodEntryDao();
        initViews(view);
        setupButtons(view);
    }

    private void initViews(View view) {
        scanResultContainer = view.findViewById(R.id.scan_result_container);
        scanLoading = view.findViewById(R.id.scan_loading);
        scanResultCard = view.findViewById(R.id.scan_result_card);
        tvFoodName = view.findViewById(R.id.tv_food_name);
        tvConfidence = view.findViewById(R.id.tv_confidence);
        tvResultCal = view.findViewById(R.id.tv_result_cal);
        tvResultProtein = view.findViewById(R.id.tv_result_protein);
        tvResultCarbs = view.findViewById(R.id.tv_result_carbs);
        tvResultFats = view.findViewById(R.id.tv_result_fats);
    }

    private void setupButtons(View view) {
        view.findViewById(R.id.btn_camera).setOnClickListener(v -> checkCameraPermission());
        view.findViewById(R.id.btn_gallery).setOnClickListener(v -> openGallery());
        view.findViewById(R.id.scan_zone).setOnClickListener(v -> checkCameraPermission());
        view.findViewById(R.id.btn_add_to_log).setOnClickListener(v -> addToLog());
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void openCamera() {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File photoFile = File.createTempFile("FOOD_" + timeStamp, ".jpg",
                requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES));

            currentPhotoUri = FileProvider.getUriForFile(
                requireContext(),
                requireContext().getPackageName() + ".fileprovider",
                photoFile
            );

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, currentPhotoUri);
            cameraLauncher.launch(intent);
        } catch (IOException e) {
            Toast.makeText(requireContext(), "Error opening camera", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        galleryLauncher.launch(intent);
    }

    private void processImage(Uri imageUri) {
        showLoading();

        try {
            File imageFile = uriToFile(imageUri);
            if (imageFile == null) {
                showError("Error reading image");
                return;
            }

            RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), imageFile);
            MultipartBody.Part imagePart = MultipartBody.Part.createFormData(
                "file", imageFile.getName(), requestBody
            );

            RetrofitClient.getInstance().getApiService()
                .predictFood(imagePart)
                .enqueue(new Callback<ScanResponse>() {
                    @Override
                    public void onResponse(@NonNull Call<ScanResponse> call,
                                          @NonNull Response<ScanResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            showResult(response.body());
                        } else {
                            showError("Server error: " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ScanResponse> call,
                                         @NonNull Throwable t) {
                        showError("Connection error: " + t.getMessage());
                    }
                });

        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }

    private void showLoading() {
        scanResultContainer.setVisibility(View.VISIBLE);
        scanLoading.setVisibility(View.VISIBLE);
        scanResultCard.setVisibility(View.GONE);
    }

    private void showResult(ScanResponse result) {
        lastScanResult = result;
        scanLoading.setVisibility(View.GONE);
        scanResultCard.setVisibility(View.VISIBLE);

        boolean isArabic = Locale.getDefault().getLanguage().equals("ar");
        tvFoodName.setText(isArabic ? result.getFoodNameAr() : result.getFoodNameEn());
        tvConfidence.setText(Math.round(result.getConfidence()) + "%");
        tvResultCal.setText(String.valueOf(result.getCalories()));
        tvResultProtein.setText(result.getProtein() + "g");
        tvResultCarbs.setText(result.getCarbs() + "g");
        tvResultFats.setText(result.getFats() + "g");
    }

    private void showError(String message) {
        scanLoading.setVisibility(View.GONE);
        scanResultContainer.setVisibility(View.GONE);
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
    }

    private void addToLog() {
        if (lastScanResult == null) return;

        FoodEntry entry = lastScanResult.toFoodEntry();
        entry.setDate(DateUtils.getTodayDbFormat());

        Executors.newSingleThreadExecutor().execute(() -> {
            dao.insert(entry);
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(),
                        Locale.getDefault().getLanguage().equals("ar")
                            ? "تم الإضافة للسجل" : "Added to log",
                        Toast.LENGTH_SHORT).show();

                    com.google.android.material.bottomnavigation.BottomNavigationView nav =
                        getActivity().findViewById(R.id.bottom_nav);
                    if (nav != null) nav.setSelectedItemId(R.id.nav_log);
                });
            }
        });
    }

    private File uriToFile(Uri uri) {
        try {
            InputStream inputStream = requireContext().getContentResolver().openInputStream(uri);
            if (inputStream == null) return null;

            File tempFile = File.createTempFile("upload_", ".jpg", requireContext().getCacheDir());
            FileOutputStream outputStream = new FileOutputStream(tempFile);

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            outputStream.close();
            inputStream.close();

            return tempFile;
        } catch (IOException e) {
            return null;
        }
    }
}
