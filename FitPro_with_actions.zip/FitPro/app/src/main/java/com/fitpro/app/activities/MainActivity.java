package com.fitpro.app.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.fitpro.app.R;
import com.fitpro.app.fragments.BodyPredictionFragment;
import com.fitpro.app.fragments.CalculatorFragment;
import com.fitpro.app.fragments.HomeFragment;
import com.fitpro.app.fragments.LogFragment;
import com.fitpro.app.fragments.ScanFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;

    private final HomeFragment homeFragment = new HomeFragment();
    private final CalculatorFragment calcFragment = new CalculatorFragment();
    private final BodyPredictionFragment bodyFragment = new BodyPredictionFragment();
    private final ScanFragment scanFragment = new ScanFragment();
    private final LogFragment logFragment = new LogFragment();
    private Fragment activeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupNavigation();
    }

    private void setupNavigation() {
        bottomNav = findViewById(R.id.bottom_nav);

        getSupportFragmentManager().beginTransaction()
            .add(R.id.fragment_container, logFragment, "log").hide(logFragment)
            .add(R.id.fragment_container, scanFragment, "scan").hide(scanFragment)
            .add(R.id.fragment_container, bodyFragment, "body").hide(bodyFragment)
            .add(R.id.fragment_container, calcFragment, "calc").hide(calcFragment)
            .add(R.id.fragment_container, homeFragment, "home")
            .commit();

        activeFragment = homeFragment;

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selected;
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                selected = homeFragment;
            } else if (itemId == R.id.nav_calc) {
                selected = calcFragment;
            } else if (itemId == R.id.nav_body) {
                selected = bodyFragment;
            } else if (itemId == R.id.nav_scan) {
                selected = scanFragment;
            } else if (itemId == R.id.nav_log) {
                selected = logFragment;
            } else {
                return false;
            }

            if (selected != activeFragment) {
                getSupportFragmentManager().beginTransaction()
                    .hide(activeFragment)
                    .show(selected)
                    .commit();
                activeFragment = selected;
            }
            return true;
        });
    }
}
