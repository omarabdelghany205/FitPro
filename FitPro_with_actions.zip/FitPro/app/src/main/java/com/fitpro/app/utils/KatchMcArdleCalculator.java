package com.fitpro.app.utils;

import com.fitpro.app.models.CalcResult;

public class KatchMcArdleCalculator {

    public static final float SEDENTARY    = 1.2f;
    public static final float LIGHT_ACTIVE = 1.375f;
    public static final float MODERATE     = 1.55f;
    public static final float VERY_ACTIVE  = 1.725f;

    public static final String GOAL_CUT  = "cut";
    public static final String GOAL_BULK = "bulk";

    public static CalcResult calculate(float weightKg, float bodyFatPct,
                                        float activityMultiplier, String goal) {

        float lbm = weightKg * (1 - bodyFatPct / 100f);
        int bmr = Math.round(370 + (21.6f * lbm));
        int tdee = Math.round(bmr * activityMultiplier);

        int targetCalories;
        float proteinPerKgLbm;

        if (GOAL_CUT.equals(goal)) {
            targetCalories = Math.round(tdee * 0.80f);
            proteinPerKgLbm = 2.2f;
        } else {
            targetCalories = Math.round(tdee * 1.15f);
            proteinPerKgLbm = 1.8f;
        }

        int proteinGrams = Math.round(lbm * proteinPerKgLbm);
        int fatsGrams = Math.round(targetCalories * 0.25f / 9f);
        int carbsGrams = Math.round(
            (targetCalories - (proteinGrams * 4f) - (fatsGrams * 9f)) / 4f
        );

        if (carbsGrams < 0) carbsGrams = 0;

        int proteinPct = Math.round(proteinGrams * 4f / targetCalories * 100f);
        int fatsPct    = Math.round(fatsGrams * 9f / targetCalories * 100f);
        int carbsPct   = 100 - proteinPct - fatsPct;

        return new CalcResult(
            bmr, tdee, targetCalories,
            proteinGrams, carbsGrams, fatsGrams,
            proteinPct, carbsPct, fatsPct,
            goal
        );
    }

    public static float getActivityMultiplier(int position) {
        switch (position) {
            case 0: return SEDENTARY;
            case 1: return LIGHT_ACTIVE;
            case 2: return MODERATE;
            case 3: return VERY_ACTIVE;
            default: return MODERATE;
        }
    }
}
