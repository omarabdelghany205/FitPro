package com.fitpro.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fitpro.app.R;
import com.fitpro.app.adapters.FoodAdapter;
import com.fitpro.app.database.AppDatabase;
import com.fitpro.app.database.FoodEntryDao;
import com.fitpro.app.models.FoodEntry;
import com.fitpro.app.utils.DateUtils;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {

    private static final int TARGET_CALORIES = 2400;
    private static final int TARGET_PROTEIN = 160;
    private static final int TARGET_CARBS = 300;
    private static final int TARGET_FATS = 75;

    private CircularProgressBar progressRing;
    private TextView tvRemaining, tvConsumed;
    private TextView tvProteinValue, tvCarbsValue, tvFatsValue;
    private View barProtein, barCarbs, barFats;
    private RecyclerView rvRecentMeals;
    private FoodAdapter adapter;
    private FoodEntryDao dao;
    private boolean isArabic;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isArabic = Locale.getDefault().getLanguage().equals("ar");
        dao = AppDatabase.getInstance(requireContext()).foodEntryDao();
        initViews(view);
        setupRecyclerView(view);
        setupQuickActions(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void initViews(View view) {
        progressRing = view.findViewById(R.id.progress_ring);
        tvRemaining = view.findViewById(R.id.tv_remaining);
        tvConsumed = view.findViewById(R.id.tv_consumed);
        tvProteinValue = view.findViewById(R.id.tv_protein_value);
        tvCarbsValue = view.findViewById(R.id.tv_carbs_value);
        tvFatsValue = view.findViewById(R.id.tv_fats_value);
        barProtein = view.findViewById(R.id.bar_protein);
        barCarbs = view.findViewById(R.id.bar_carbs);
        barFats = view.findViewById(R.id.bar_fats);

        progressRing.setProgressBarColorStart(0xFFE8D5A0);
        progressRing.setProgressBarColorEnd(0xFFC8A960);
        progressRing.setProgressBarWidth(8f);
        progressRing.setBackgroundProgressBarWidth(8f);
        progressRing.setBackgroundProgressBarColor(0x0DFFFFFF);
        progressRing.setRoundBorder(true);
        progressRing.setProgressMax(100f);
    }

    private void setupRecyclerView(View view) {
        rvRecentMeals = view.findViewById(R.id.rv_recent_meals);
        adapter = new FoodAdapter(isArabic);
        rvRecentMeals.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvRecentMeals.setAdapter(adapter);
    }

    private void setupQuickActions(View view) {
        view.findViewById(R.id.quick_calc).setOnClickListener(v -> navigateTo(R.id.nav_calc));
        view.findViewById(R.id.quick_scan).setOnClickListener(v -> navigateTo(R.id.nav_scan));
        view.findViewById(R.id.quick_log).setOnClickListener(v -> navigateTo(R.id.nav_log));
    }

    private void navigateTo(int navId) {
        if (getActivity() != null) {
            com.google.android.material.bottomnavigation.BottomNavigationView nav =
                getActivity().findViewById(R.id.bottom_nav);
            if (nav != null) nav.setSelectedItemId(navId);
        }
    }

    private void loadData() {
        Executors.newSingleThreadExecutor().execute(() -> {
            String today = DateUtils.getTodayDbFormat();
            List<FoodEntry> entries = dao.getEntriesByDate(today);
            int totalCal = dao.getTotalCaloriesByDate(today);
            int totalP = dao.getTotalProteinByDate(today);
            int totalC = dao.getTotalCarbsByDate(today);
            int totalF = dao.getTotalFatsByDate(today);

            if (getActivity() != null) {
                getActivity().runOnUiThread(() ->
                    updateUI(entries, totalCal, totalP, totalC, totalF));
            }
        });
    }

    private void updateUI(List<FoodEntry> entries, int cal, int p, int c, int f) {
        int remaining = Math.max(0, TARGET_CALORIES - cal);
        float pct = Math.min(100f, (float) cal / TARGET_CALORIES * 100f);

        tvConsumed.setText(String.valueOf(cal));
        tvRemaining.setText(String.valueOf(remaining));
        progressRing.setProgressWithAnimation(pct, 1200L);

        tvProteinValue.setText(p + "/" + TARGET_PROTEIN + "g");
        tvCarbsValue.setText(c + "/" + TARGET_CARBS + "g");
        tvFatsValue.setText(f + "/" + TARGET_FATS + "g");

        setBarWidth(barProtein, (float) p / TARGET_PROTEIN);
        setBarWidth(barCarbs, (float) c / TARGET_CARBS);
        setBarWidth(barFats, (float) f / TARGET_FATS);

        adapter.setEntries(entries);
    }

    private void setBarWidth(View bar, float fraction) {
        ViewGroup.LayoutParams params = bar.getLayoutParams();
        ViewGroup parent = (ViewGroup) bar.getParent();
        int parentWidth = parent.getWidth();
        if (parentWidth > 0) {
            params.width = (int) (parentWidth * Math.min(1f, fraction));
            bar.setLayoutParams(params);
        }
    }
}
