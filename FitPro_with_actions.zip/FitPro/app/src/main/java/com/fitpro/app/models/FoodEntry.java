package com.fitpro.app.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "food_entries")
public class FoodEntry {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nameAr;
    private String nameEn;
    private int calories;
    private int protein;
    private int carbs;
    private int fats;
    private String emoji;
    private float confidence;
    private long timestamp;
    private String date;

    public FoodEntry() {}

    public FoodEntry(String nameAr, String nameEn, int calories,
                     int protein, int carbs, int fats, String emoji) {
        this.nameAr = nameAr;
        this.nameEn = nameEn;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fats = fats;
        this.emoji = emoji;
        this.timestamp = System.currentTimeMillis();
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNameAr() { return nameAr; }
    public void setNameAr(String nameAr) { this.nameAr = nameAr; }
    public String getNameEn() { return nameEn; }
    public void setNameEn(String nameEn) { this.nameEn = nameEn; }
    public int getCalories() { return calories; }
    public void setCalories(int calories) { this.calories = calories; }
    public int getProtein() { return protein; }
    public void setProtein(int protein) { this.protein = protein; }
    public int getCarbs() { return carbs; }
    public void setCarbs(int carbs) { this.carbs = carbs; }
    public int getFats() { return fats; }
    public void setFats(int fats) { this.fats = fats; }
    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public float getConfidence() { return confidence; }
    public void setConfidence(float confidence) { this.confidence = confidence; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getDisplayName(boolean isArabic) {
        return isArabic ? nameAr : nameEn;
    }

    public String getMacrosSummary() {
        return protein + "g P · " + carbs + "g C · " + fats + "g F";
    }
}
