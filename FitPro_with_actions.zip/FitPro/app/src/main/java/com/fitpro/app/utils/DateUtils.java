package com.fitpro.app.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateUtils {

    private static final SimpleDateFormat DB_FORMAT =
        new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    private static final SimpleDateFormat DISPLAY_FORMAT_AR =
        new SimpleDateFormat("EEEE، d MMMM yyyy", new Locale("ar"));

    private static final SimpleDateFormat DISPLAY_FORMAT_EN =
        new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US);

    public static String getTodayDbFormat() {
        return DB_FORMAT.format(new Date());
    }

    public static String getDisplayDate(boolean isArabic) {
        if (isArabic) {
            return DISPLAY_FORMAT_AR.format(new Date());
        } else {
            return DISPLAY_FORMAT_EN.format(new Date());
        }
    }
}
