-keepattributes Signature
-keepattributes *Annotation*
-keep class com.fitpro.app.models.** { *; }
-keep class retrofit2.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

-keep class com.google.gson.** { *; }

-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
